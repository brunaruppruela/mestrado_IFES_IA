(ns ifes.pl0.core-test
  (:require [clojure.test :refer :all]
            [ifes.pl0.core :refer :all]))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
